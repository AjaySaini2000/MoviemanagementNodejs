const mongoose=require('mongoose')


const categorySchema=mongoose.Schema({
    category:{
        type:String,
        unique:true
    }
})

module.exports=mongoose.model('moviecategory',categorySchema)