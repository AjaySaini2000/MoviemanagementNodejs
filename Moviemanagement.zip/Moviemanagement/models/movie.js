
const mongoose=require('mongoose')

const movieSchema=mongoose.Schema({
    movieName:{
        type:String
    },
    movieDesc:{
        type:String
    },
    movieCategory:{
        type:String
    },
    releaseDate:{
        type:Date,
        default:new Date()
    }
})

module.exports=mongoose.model('moviedata',movieSchema)