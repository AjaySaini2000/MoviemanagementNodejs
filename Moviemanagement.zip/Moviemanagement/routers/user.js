const router=require('express').Router()
const moviec=require('../controllers/moviecontroller')







module.exports=router