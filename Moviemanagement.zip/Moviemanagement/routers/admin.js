const router=require('express').Router()
const moviec=require('../controllers/moviecontroller')
const categoryc=require('../controllers/categorycontroller')


router.get('/adminpanel',(req,res)=>{
    res.render('admin/deshboard.ejs')
})
router.get('/categories',categoryc.categories)
router.get('/addcategories',categoryc.categoryform)
router.post('/addcategories',categoryc.categorydata)


router.get('/movies/:mess',moviec.movies)
router.get('/movieform',moviec.movieform)
router.post('/movieform',moviec.movieformdata)
router.get('/deletemovies/:id',moviec.deletemovie)
router.get('/deletecategory/:id',categoryc.deletecategory)


module.exports=router