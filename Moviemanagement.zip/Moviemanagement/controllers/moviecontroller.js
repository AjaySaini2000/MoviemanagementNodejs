const movieTable=require('../models/movie')
const categoryTable=require('../models/moviecategory')



exports.movieform=async(req,res)=>{
    const data=await categoryTable.find()
    res.render('admin/movieform.ejs',{data})
}

exports.movieformdata=(req,res)=>{
const{moviename,moviedesc,categorie}=req.body
const newRecord=new movieTable({movieName:moviename,movieDesc:moviedesc,movieCategory:categorie})
newRecord.save()
const message='movie successfully released'
res.redirect(`/admin/movies/${message}`)
}

exports.movies=async(req,res)=>{
    let message=req.params.mess
    let catedata=await categoryTable.find()
    
    if(req.params.mess=='mess'){
    
    const data=await movieTable.find()
    
    // console.log(message)

    res.render('admin/moviemanagement.ejs',{catedata,data,message})
    }
    else if(req.params.mess=='search'){
        
        // const (req.query.Search)
       const data=await movieTable.find({movieCategory:req.query.Search})
        res.render('admin/moviemanagement.ejs',{catedata,data,message})
    }
    else{
       
        const data=await movieTable.find()
       
        res.render('admin/moviemanagement.ejs',{catedata,data,message})
    }
}
exports.deletemovie=async(req,res)=>{
    const id=req.params.id
    await movieTable.findByIdAndDelete(id)
res.redirect('/admin/movies/mess')
}