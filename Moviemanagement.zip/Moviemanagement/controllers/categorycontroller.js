const categoryTable=require('../models/moviecategory')








exports.categoryform=(req,res)=>{
    res.render('admin/addcategory.ejs')
}

exports.categorydata=(req,res)=>{
    const{addcategory}=req.body
   const newRecord= new categoryTable({category:addcategory})
   newRecord.save()
}
exports.categories=async(req,res)=>{
    const data=await categoryTable.find()
    // console.log(data)
    res.render('admin/categorymanagement.ejs',{data})
}
exports.deletecategory=async(req,res)=>{
    const id=req.params.id
    await categoryTable.findByIdAndDelete(id)
    res.redirect('/admin/categories/')
}